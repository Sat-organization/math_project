
import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
import io
import base64
from collections import Counter
from scipy import stats

from django.http import JsonResponse
from scipy.optimize import linprog
from django.shortcuts import render
import math
import re
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 设置支持中文的字体 SimHei（黑体）
plt.rcParams['font.sans-serif'] = ['SimHei']  # 或者 'SimSun' 用于宋体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示为方块的问题

def factorial(n):
    return math.factorial(n)

def to_halfwidth(text):
    """将全角字符转换为半角字符"""
    return text.translate(str.maketrans({
        '，': ',',  # 全角逗号 -> 半角逗号
        '。': '.',  # 全角句号 -> 半角句号
        '！': '!',  # 全角感叹号 -> 半角感叹号
        '？': '?',  # 全角问号 -> 半角问号
        '：': ':',  # 全角冒号 -> 半角冒号
        '；': ';',  # 全角分号 -> 半角分号
        '（': '(',  # 全角左括号 -> 半角左括号
        '）': ')',  # 全角右括号 -> 半角右括号
        '“': '"',  # 全角左引号 -> 半角引号
        '”': '"',  # 全角右引号 -> 半角引号
     }))

def basic_calculation(request):
    result = ''
    if request.method == 'POST':
        expression = request.POST.get('expression')

        # 处理组合数 C(m,n) 和 排列数 A(m,n)
        expression = re.sub(r'C\((\d+),\s*(\d+)\)', lambda m: str(math.comb(int(m.group(1)), int(m.group(2)))), expression)
        expression = re.sub(r'A\((\d+),\s*(\d+)\)', lambda m: str(math.perm(int(m.group(1)), int(m.group(2)))), expression)

        # 处理 log(m, n)
        expression = re.sub(r'log\((\d+),\s*(\d+)\)', lambda m: str(math.log(int(m.group(2)), int(m.group(1)))), expression)

        # 替换 e 和 π
        expression = expression.replace('e', str(math.e))
        expression = expression.replace('π', str(math.pi))

        # 替换三角函数和反三角函数
        expression = expression.replace('sin', 'math.sin')
        expression = expression.replace('cos', 'math.cos')
        expression = expression.replace('tan', 'math.tan')
        #expression = expression.replace('arcsin', 'math.asin')
        #expression = expression.replace('arccos', 'math.acos')
        #expression = expression.replace('arctan', 'math.atan')

        # 处理指数符号 ^ 和阶乘
        expression = expression.replace('^', '**')
        expression = re.sub(r'(\d+)\!', lambda m: str(math.factorial(int(m.group(1)))), expression)

        # 处理 ln
        expression = expression.replace('ln', 'math.log')

        # 处理平方根
        expression = re.sub(r'√\s*\(?', 'math.sqrt(', expression)

        # 计算其他表达式
        #   result = eval(expression)
        #except Exception as e:
        #    return JsonResponse({'result': '错误: ' + str(e)})

        try:
            result = eval(expression)
        except SyntaxError as e:
            return JsonResponse({'result': '语法错误: ' + str(e)})
        except NameError as e:
            return JsonResponse({'result': '未定义的名称: ' + str(e)})
        except Exception as e:
            return JsonResponse({'result': '错误: ' + str(e)})

        return JsonResponse({'result': result})

    return render(request, 'calculator/basic_calculation.html', {'result': result})

def linear_algebra(request):
    result = {}
    if request.method == 'POST':
        # 矩阵运算部分
        matrix_str = request.POST.get('matrix')
        operation = request.POST.get('operation')

        try:
            matrix = np.array(eval(matrix_str))

            if operation == 'add':
                matrix2_str = request.POST.get('matrix2')
                matrix2 = np.array(eval(matrix2_str))
                if matrix.shape != matrix2.shape:
                    result['error'] = '矩阵维数不一致，无法进行加法'
                else:
                    result['result'] = matrix + matrix2

            elif operation == 'subtract':
                matrix2_str = request.POST.get('matrix2')
                matrix2 = np.array(eval(matrix2_str))
                if matrix.shape != matrix2.shape:
                    result['error'] = '矩阵维数不一致，无法进行减法'
                else:
                    result['result'] = matrix - matrix2

            elif operation == 'multiply':
                matrix2_str = request.POST.get('matrix2')
                matrix2 = np.array(eval(matrix2_str))
                if matrix.shape[1] != matrix2.shape[0]:
                    result['error'] = '矩阵维数不一致，无法进行乘法'
                else:
                    result['result'] = np.dot(matrix, matrix2)

            elif operation == 'inverse':
                if matrix.shape[0] == matrix.shape[1] and np.linalg.det(matrix) != 0:
                    result['result'] = np.linalg.inv(matrix)
                else:
                    result['error'] = '该矩阵不可逆'

            elif operation == 'properties':
                result['shape'] = matrix.shape
                result['rank'] = np.linalg.matrix_rank(matrix)
                result['det'] = np.linalg.det(matrix) if matrix.shape[0] == matrix.shape[1] else None
                result['eigenvalues'] = np.linalg.eigvals(matrix)
                if matrix.shape[0] == matrix.shape[1]:
                    eigvals, eigvecs = np.linalg.eig(matrix)
                    result['eigenvectors'] = eigvecs

        except Exception as e:
            result['error'] = str(e)

        # 解线性方程组部分
        if request.POST.get('operation') == 'solve_system':
            matrix_str = request.POST.get('matrix')
            b_str = request.POST.get('b')

            try:
                A = np.array(eval(matrix_str))
                b = np.array(eval(b_str))

                if A.shape[0] != b.shape[0]:
                    result['error'] = '矩阵A的行数与向量b的维数不一致'
                else:
                    solution = np.linalg.solve(A, b)
                    result['solution'] = solution.tolist()

            except np.linalg.LinAlgError as e:
                result['solution'] = '无解或无穷解'
            except Exception as e:
                result['error'] = str(e)

        # 求解线性规划部分
        if request.POST.get('operation') == 'solve_lp':
            c_str = request.POST.get('c')
            A_str = request.POST.get('matrix')
            b_str = request.POST.get('b')
            optimization = request.POST.get('optimization')

            try:
                c = np.array(eval(c_str))
                A = np.array(eval(A_str))
                b = np.array(eval(b_str))

                if optimization == 'min':
                    res = linprog(c, A_ub=A, b_ub=b)
                else:
                    res = linprog(-c, A_ub=A, b_ub=b)

                if res.success:
                    result['lp_solution'] = res.x.tolist()
                    result['lp_status'] = '唯一最优解' if res.status == 0 else '可选择的最优解'
                else:
                    result['lp_status'] = '无解或无界'
            except Exception as e:
                result['error'] = str(e)

    return render(request, 'calculator/linear_algebra.html', {'result': result})


def statistics(request):
    result = {}
    graph = ''
    previous_data = ''
    previous_data1 = ''
    previous_data2 = ''
    mode = 'single'

    if request.method == 'POST':
        mode = request.POST.get('mode', 'single')

        if mode == 'double':
            data_str1 = request.POST.get('data1') or request.POST.get('previous_data1')
            data_str2 = request.POST.get('data2') or request.POST.get('previous_data2')
            operation = request.POST.get('operation')

            try:
                if not data_str1 or not data_str2:
                    raise ValueError("请提供两个数据集。")
                
                data_str1 = to_halfwidth(data_str1)
                data_str2 = to_halfwidth(data_str2)

                data_items1 = re.split(r'[,\s]+', data_str1.strip())
                data_items2 = re.split(r'[,\s]+', data_str2.strip())

                data1 = np.array([float(item) for item in data_items1 if item])
                data2 = np.array([float(item) for item in data_items2 if item])
                
                if len(data1) != len(data2):
                    raise ValueError("两个数据集的长度必须相同。")

                if operation == 'covariance':
                    result['covariance'] = np.cov(data1, data2)[0][1]
                elif operation == 'correlation':
                    result['correlation'] = np.corrcoef(data1, data2)[0][1]
                elif operation == 'linear_regression':
                    slope, intercept, r_value, p_value, std_err = stats.linregress(data1, data2)
                    result['slope'] = slope
                    result['intercept'] = intercept
                    result['r_squared'] = r_value**2
                    
                    # 绘制散点图和回归线
                    plt.figure()
                    plt.scatter(data1, data2, color='blue', label='数据点')
                    plt.plot(data1, slope * data1 + intercept, color='red', label='回归线')

                    # 显示回归方程
                    equation_text = f'               y = {slope:.2f}x + {intercept:.2f}'
                    plt.text(np.min(data1), np.max(data2), equation_text, fontsize=12, color='black', ha='left')
                    plt.title('散点图及线性回归线')
                    plt.xlabel('数据1')
                    plt.ylabel('数据2')
                    plt.legend()
                    buf = io.BytesIO()
                    plt.savefig(buf, format='png')
                    plt.close()
                    buf.seek(0)
                    graph = base64.b64encode(buf.read()).decode('utf-8')

            except Exception as e:
                result['error'] = str(e)
            
            previous_data1 = data_str1
            previous_data2 = data_str2

        else:
            data_str = request.POST.get('data') or request.POST.get('previous_data')
            operation = request.POST.get('operation')

            # 处理单变量数据
            try:
                if not data_str:
                    raise ValueError("请提供数据。")

                data_str = to_halfwidth(data_str)
                data_items = re.split(r'[,\s]+', data_str.strip())
                data = np.array([float(item) for item in data_items if item])

                if len(data) == 0:
                    raise ValueError("没有提供任何数据。")

                if operation == 'mean':
                    result['mean'] = np.mean(data)
                elif operation == 'median':
                    result['median'] = np.median(data)
                elif operation == 'mode':
                    count = Counter(data)
                    max_count = max(count.values())
                    modes = [k for k, v in count.items() if v == max_count]
                    result['mode'] = modes
                    result['mode_count'] = max_count
                elif operation == 'variance':
                    result['variance'] = np.var(data, ddof=1)
                elif operation == 'std_dev':
                    result['std_dev'] = np.std(data, ddof=1)
                elif operation == 'summary':
                    result['mean'] = np.mean(data)
                    result['median'] = np.median(data)
                    count = Counter(data)
                    max_count = max(count.values())
                    modes = [k for k, v in count.items() if v == max_count]
                    result['mode'] = modes
                    result['mode_count'] = max_count
                    result['variance'] = np.var(data, ddof=1)
                    result['std_dev'] = np.std(data, ddof=1)
                elif operation == 'plot_histogram':
                    plt.figure()
                    plt.hist(data, bins='auto', color='blue', alpha=0.7, rwidth=0.85)
                    plt.title('直方图')
                    plt.xlabel('数据值')
                    plt.ylabel('频率')
                    plt.grid(True)
                    buf = io.BytesIO()
                    plt.savefig(buf, format='png')
                    plt.close()
                    buf.seek(0)
                    graph = base64.b64encode(buf.read()).decode('utf-8')
                elif operation == 'plot_boxplot':
                    plt.figure()
                    plt.boxplot(data)
                    plt.title('盒须图')
                    plt.grid(True)
                    buf = io.BytesIO()
                    plt.savefig(buf, format='png')
                    plt.close()
                    buf.seek(0)
                    graph = base64.b64encode(buf.read()).decode('utf-8')
                else:
                    raise ValueError("未知的操作类型。")

            except Exception as e:
                result['error'] = str(e)
            
            previous_data = data_str

    return render(request, 'calculator/statistics.html', {
        'result': result,
        'graph': graph,
        'previous_data': previous_data,
        'previous_data1': previous_data1,
        'previous_data2': previous_data2,
        'mode': mode,
    })




from django.shortcuts import render
import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
import io
import base64
import plotly.graph_objects as go

def calculus(request):
    result = {}
    graph = ''
    if request.method == 'POST':
        function_str = request.POST.get('function')
        x, y, z = sp.symbols('x y z')

        function = sp.sympify(function_str)

        # 一元函数处理
        if function.has(x) and not function.has(y) and not function.has(z):
            derivative = sp.diff(function, x)
            second_derivative = sp.diff(derivative, x)
            integral = sp.integrate(function, x)

            result['function'] = function
            result['derivative'] = derivative
            result['second_derivative'] = second_derivative
            result['integral'] = integral

            # 绘图
            f_lambdified = sp.lambdify(x, function, modules='numpy')
            x_vals = np.linspace(-10, 10, 400)
            y_vals = f_lambdified(x_vals)

            # 使用 Plotly 绘制交互式图形
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=x_vals, y=y_vals, mode='lines', name=str(function)))
            fig.update_layout(title='函数图像',
                              xaxis_title='x',
                              yaxis_title='f(x)',
                              showlegend=True)
            graph = fig.to_html(full_html=False)

        # 多元函数处理
        elif function.has(x) or function.has(y) or function.has(z):
            result['function'] = function
            partial_derivatives = {}
            second_partial_derivatives = {}

            # 计算一阶偏导和二阶偏导
            if function.has(x):
                partial_derivatives['∂/∂x'] = sp.diff(function, x)
                second_partial_derivatives['∂²/∂x²'] = sp.diff(partial_derivatives['∂/∂x'], x)

            if function.has(y):
                partial_derivatives['∂/∂y'] = sp.diff(function, y)
                second_partial_derivatives['∂²/∂y²'] = sp.diff(partial_derivatives['∂/∂y'], y)

            if function.has(z):
                partial_derivatives['∂/∂z'] = sp.diff(function, z)
                second_partial_derivatives['∂²/∂z²'] = sp.diff(partial_derivatives['∂/∂z'], z)

            result['partial_derivatives'] = partial_derivatives
            result['second_partial_derivatives'] = second_partial_derivatives

            # 绘图（如果是二元函数）
            if function.has(x) and function.has(y) and not function.has(z):
                X, Y = np.meshgrid(np.linspace(-5, 5, 100), np.linspace(-5, 5, 100))
                f_lambdified = sp.lambdify((x, y), function, modules='numpy')
                Z = f_lambdified(X, Y)

                # 使用 Plotly 绘制二元函数图像
                fig = go.Figure(data=[go.Surface(z=Z, x=X, y=Y)])
                fig.update_layout(title='二元函数图像',
                                  scene=dict(
                                      xaxis_title='x',
                                      yaxis_title='y',
                                      zaxis_title='f(x, y)',
                                  ))
                graph = fig.to_html(full_html=False)

            else:
                result['error'] = "无法绘制三维图像，因变量数量过多。"

    return render(request, 'calculator/calculus.html', {'result': result, 'graph': graph})